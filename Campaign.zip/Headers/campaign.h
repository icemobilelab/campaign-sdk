//
//  campaign.h
//  campaign
//
//  Created by Leonardo Rossetto on 02/02/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for campaign.
FOUNDATION_EXPORT double campaignVersionNumber;

//! Project version string for campaign.
FOUNDATION_EXPORT const unsigned char campaignVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <campaign/PublicHeader.h>


